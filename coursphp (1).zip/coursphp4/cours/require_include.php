<?php 
    require_once "fonctionsReq.php";
    // require_once "separateur.php";
    // require_once "separateur.php";
    // require_once "separateur.php";
    // require_once "separateur.php";
    // require_once "separateur.php";
    // echo addition(12.3,45.1);
    // echo "<br>Bonjour toi !";

    // if(ouiOuNon("Voulez-vous faire une addition ?")){
    //     echo addition(10,5);
    // }else{
    //     echo "Vous avez décidé de ne pas faire une addition.\nAurevoir";
    // }

    //exo1
    // if(ouiOuNon("Voulez-vous faire une soustraction ?")){
    //     echo soustraction(10,5);
    // }else{
    //     echo "Vous avez décidé de ne pas faire une soustraction.\nAurevoir";
    // }

    //exo2
    // if(ouiOuNon("Voulez-vous faire une multiplication ?")){
    //     echo multiplication(10,5);
    // }else{
    //     echo "Vous avez décidé de ne pas faire une multiplication.\nAurevoir";
    // }

    //exo3
    // if(ouiOuNon("Voulez-vous faire une division ?")){
    //     $nb1 = 10;
    //     $nb2 = 0;
    //     if ($nb2 == 0){
    //         echo "Erreur. Vous avez tenté une division par 0 !!!";
    //     }else{
    //         echo division($nb1,$nb2);
    //     }
    // }else{
    //     echo "Vous avez décidé de ne pas faire une division.\nAurevoir";
    // }

    //exo4
    // if(ouiOuNon("Voulez-vous faire une addition ?")){
    //     $nb1 = readline("Veuillez introduire un 1er nombre : ");
    //     $nb2 = readline("Veuillez introduire un 2ème nombre : ");
    //     if(is_numeric($nb1) && is_numeric($nb2)){
    //         echo "Le resultat de l'addition est : " . addition($nb1,$nb2). "\n";
    //     }else{
    //         echo "Vous n'avez pas introduis 2 nombres\n";
    //     }
    // }else{
    //     echo "Vous avez décidé de ne pas faire une addition.\nAurevoir\n";
    // }

    // require "separateur.php";
    

    //exo5.1
    // if(ouiOuNon("Voulez-vous faire une soustraction ?")){
    //     $nb1 = readline("Veuillez introduire un 1er nombre : ");
    //     $nb2 = readline("Veuillez introduire un 2ème nombre : ");
    //     if(is_numeric($nb1) && is_numeric($nb2)){
    //         echo "Le resultat de la soustraction est : " . soustraction($nb1,$nb2). "\n";
    //     }else{
    //         echo "Vous n'avez pas introduis 2 nombres\n";
    //     }
    // }else{
    //     echo "Vous avez décidé de ne pas faire une soustraction.\nAurevoir\n";
    // }
    // require "separateur.php";


     //exo5.2
    // if(ouiOuNon("Voulez-vous faire une multiplication ?")){
    //     $nb1 = readline("Veuillez introduire un 1er nombre : ");
    //     $nb2 = readline("Veuillez introduire un 2ème nombre : ");
    //     if(is_numeric($nb1) && is_numeric($nb2)){
    //         echo "Le resultat de la multiplication est : " . multiplication($nb1,$nb2). "\n";
    //     }else{
    //         echo "Vous n'avez pas introduis 2 nombres\n";
    //     }
    // }else{
    //     echo "Vous avez décidé de ne pas faire une multiplication.\nAurevoir";
    // }

    
   
?>
