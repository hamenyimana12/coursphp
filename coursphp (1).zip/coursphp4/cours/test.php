<?php
    // $firstname = "Julien";
    // echo 'Bonjour ' . $firstname  .', bienvenue dans le monde du PHP ';

    //exo1 et exo2
    // $firstname = "Zak";
    // $lastname = "Bena";
    // $poids = 70;
    // $age = 80;
    // echo "Voici ". $firstname ." ". $lastname.", il a ". $age . " ans et un poids de ". $poids . " Kilos.";
    
    //exo3
    // $nb1 = 10;
    // $nb2 = 30;
    // $nb3 = 48;
    // echo ($nb1+$nb2+$nb3)/3;

    //exo4
    // $nb1 = 10;
    // $nb2 = 30;
    // $nb3 = 48;
    // $sommes = $nb1 + $nb2 + $nb3;
    // $moyenne = $sommes/3;
    // echo "Voici 3 nombres : ". $nb1.", ".$nb2." et ".$nb3. ", la moyenne de ces nombres donne : " . $moyenne;

    //différence "" et ''
    // $nb1 = 10;
    // $nb2 = 30;
    // $nb3 = 48;
    // $sommes = $nb1 + $nb2 + $nb3;
    // $moyenne = $sommes/3;
    // echo "Voici 3 \"nombres\" : ". $nb1.", ".$nb2." et ".$nb3;
    // echo "\nla moyenne de ces nombres donne : $moyenne \n";
    // echo 'Je m\'appel Julien';

    // $firstname = "Kevin";
    // $lastname = "DeBruyne";
    // // echo "Le prénom c'est $firstname, le nom c'est $lastname \n";
    // // echo 'Le prénom c\'est $firstname, le nom c\'est $lastname'. "\n";
    // echo "Le prenom c'est $firstname, <br>le nom c'est $lastname";


    $estValide = true;
    echo $estValide."\n";

    $estValide = false;
    echo $estValide;

    $adresse = null;
    echo $adresse;

?>